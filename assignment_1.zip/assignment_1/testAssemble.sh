./pgmAssemble Assembled.pgm 512 512 0 0 test_0_0.pgm 0 1 test_0_1.pgm 0 2 test_0_2.pgm 1 0 test_1_0.pgm 1 1 test_1_1.pgm 1 2 test_1_2.pgm 2 0 test_2_0.pgm 2 1 test_2_1.pgm 2 2 test_2_2.pgm
