//Header file for the pgma2b file
//
//Brooklyn Mcswiney

//Main method to read in cmd line arguments
//argc = Number of command line arguments
//argv[1] = name of image file to be inputted in ASCII
//argv[2] = name of image file to be outputted in binary
int main(int argc, char **argv);
