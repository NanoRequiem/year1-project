

int main(int argc, char **argv);

int initImageList(Image **ImageList, int numbOfImage);
