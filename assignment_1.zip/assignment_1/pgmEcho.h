
//Header file for the pgmEcho program
//
//Brooklyn Mcswiney

//Main method to read in cmd line arguments
//argc = Number of command line arguments
//argv[1] = name of image file to be inputted
//argv[2] = name of image file to be outputted
int main(int argc, char **argv);
