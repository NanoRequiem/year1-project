
int checkTemplate(char *inputString);

int getOutputName(char *outputTemplate, char *outputName, int x, int y);
