//Module to free data should any part fail
int freeImage(Image *inputImage);